#include <avr/io.h>
#include <util/delay.h>

#define BLINK_DELAY_MS 150
int main(void)
{
    DDRB = DDRB | (1 << 2) | (1 << 3) | (1 << 4) | (1 << 5);   /* configure pin i of PORTB for output*/
    while (1)
    {
        for (int i = 5; i > 2; i--)
        {
            PORTB = PORTB | (1 << i); /* set pin i high to turn led on */
            _delay_ms(BLINK_DELAY_MS);
            PORTB = PORTB & ~(1 << i); /* set pin i low to turn led off */
        }

        for (int i = 2; i < 5; i++)
        {
            PORTB = PORTB | (1 << i); /* set pin i high to turn led on */
            _delay_ms(BLINK_DELAY_MS);
            PORTB = PORTB & ~(1 << i); /* set pin i low to turn led off */
        }
    }
}